﻿
namespace Green;

internal class Rating
{
    public string Source { get; set; }
    public string Value { get; set; }
}
